'''
Created on 04/10/2014
Otra forma de hacer la tabla de multiplicacion del num 9
@author: A01221672
'''

def multiplica():
    for i in range (11):
        print( i *9,)
multiplica()

