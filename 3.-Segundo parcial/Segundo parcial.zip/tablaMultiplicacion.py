'''
Created on 04/10/2014
Rotacion de una figura alrededor de un circulo
@author: A01221672
'''

def multiplyNumber(n):
    i = 0
    for x in range (11):
        print(n *i)
        i += 1
multiplyNumber(5)
