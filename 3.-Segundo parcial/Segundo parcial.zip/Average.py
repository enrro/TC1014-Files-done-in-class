'''
Created on 04/10/2014
Create a function to calculate the average. Parameters are the sum and the number of elements.
@author: A01221672
'''
def calculateAverage(suma,numbers):
    return suma/numbers

print(calculateAverage(32543875021422058782.0,242.0))
