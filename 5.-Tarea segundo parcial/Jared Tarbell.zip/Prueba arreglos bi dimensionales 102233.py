'''
Created on 22/10/2014
Prueba de la capacidad de los arreglos bi dimensionales
Proven and tested on python 3.3.3
@author: A01221672
'''
for primero in range(5):
    for segundo in range(5):
        print("P " + str(primero), " S "+ str(segundo), end = '\t')
    print()
